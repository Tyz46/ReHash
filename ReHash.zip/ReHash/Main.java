
import java.util.Random;

public class Main {

    public static void main(String[] args) {
        int[] matriz = new int[100];
        boolean[] ocupado = new boolean[100];
        int[] elementos = new int[100];
        int[] colisoesElemento = new int[100];
        Random random = new Random(1090);
        int quantidadeInserida = 0;
        int totalColisoes = 0;
        int quantidadeRejeitada = 0;

        // tres elementos que mais colidiram
        int maior1 = -1;
        int maior2 = -1;
        int maior3 = -1;
        int elemento1 = 0;
        int elemento2 = 0;
        int elemento3 = 0;

        // inserindo 100 elementos
        for (int i = 0; i < 100; i++) {
            int numero = random.nextInt(100001);
            // ver se atingiu 90% da ocupação
            if (quantidadeInserida >= 90) {
                quantidadeRejeitada++;
            } else {
                int posicao = numero % 100;
                int colisoes = 0;

                // res com sondagem linear
                while (ocupado[posicao] == true) {
                    colisoes++;
                    posicao = posicao + 1;
                    if (posicao == 100) {
                        posicao = 0;
                    }
                }

                // inserindo o elemento
                matriz[posicao] = numero;
                ocupado[posicao] = true;

                elementos[quantidadeInserida] = numero;
                colisoesElemento[quantidadeInserida] = colisoes;

                quantidadeInserida++;

                totalColisoes = totalColisoes + colisoes;

                // ver os elementos que mais colidiram
                if (colisoes > maior1) {
                    maior3 = maior2;
                    elemento3 = elemento2;

                    maior2 = maior1;
                    elemento2 = elemento1;

                    maior1 = colisoes;
                    elemento1 = numero;
                } else if (colisoes > maior2) {
                    maior3 = maior2;
                    elemento3 = elemento2;

                    maior2 = colisoes;
                    elemento2 = numero;
                } else if (colisoes > maior3) {
                    maior3 = colisoes;
                    elemento3 = numero;
                }
            }
        }

        // resultados
        System.out.println("RESULTADOS:");
        System.out.println("Elementos inseridos: " + quantidadeInserida);
        System.out.println("Elementos rejeitados: " + quantidadeRejeitada);
        System.out.println("Total de colisoes: " + totalColisoes);
        // os tres com mais colisões
        System.out.println("\nELEMENTOS QUE MAIS COLIDIRAM:");
        System.out.println(elemento1 + " - " + maior1 + " colisoes");
        System.out.println(elemento2 + " - " + maior2 + " colisoes");
        System.out.println(elemento3 + " - " + maior3 + " colisoes");
        // Posicoes livres
        System.out.println("\nPOSICOES LIVRES:");

        for (int i = 0; i < 100; i++) {
            if (ocupado[i] == false) {
                System.out.print(i + " ");
            }
        }

        // busca
        System.out.println("\n\nTESTE DE BUSCA:");

        int[] buscar = new int[3];
        buscar[0] = elemento1;
        buscar[1] = elemento2;
        buscar[2] = elemento3;

        for (int i = 0; i < 3; i++) {
            int numero = buscar[i];
            int posicao = numero % 100;
            int tentativas = 0;
            boolean encontrado = false;

            while (ocupado[posicao] == true &&
                   tentativas < 100 &&
                   encontrado == false) {

                if (matriz[posicao] == numero) {
                    encontrado = true;
                } else {
                    posicao++;
                    if (posicao == 100) {
                        posicao = 0;
                    }
                    tentativas++;
                }
            }

            if (encontrado == true) {
                System.out.println(numero + " encontrado na posicao " + posicao);
            } else {
                System.out.println(numero + " nao encontrado");
            }
        }
    }
}
